#!/usr/bin/env bash
###############################################################################
#
#   Merve için bypass  —  created by pargusz
#
#   Discord ve engelli sitelere VPN'siz erisim (DPI atlatma) - tasinabilir surum.
#   Windows'taki GoodbyeDPI gibi: KURULUM YOK, INDIRME YOK.
#   Klasoru ac, calistir, birak. Pencereyi kapatinca durur.
#
#   Kullanim:
#       sudo ./bypass.sh              # varsayilan yontem
#       sudo ./bypass.sh ttl          # alternatif 1 (TTL)
#       sudo ./bypass.sh badseq       # alternatif 2 (yanlis sira/checksum)
#
###############################################################################
set -euo pipefail

# --- Bu betigin bulundugu klasor (her yerden calistirilabilsin) ---------------
SELF="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/$(basename "${BASH_SOURCE[0]}")"
DIR="$(dirname "$SELF")"

export PATH="/usr/sbin:/usr/bin:/sbin:/bin:${PATH:-}"

TABLE="bypass"          # nftables tablo adi
QNUM=200                # NFQUEUE numarasi
MARK="0x40000000"       # nfqws'in enjekte ettigi paketlerin isareti (dongu onleme)
UDP_LO=50000            # Discord ses/medya UDP port araligi
UDP_HI=65535

STRAT="${1:-varsayilan}"

# --- Renkler ------------------------------------------------------------------
if [[ -t 1 ]]; then
    R=$'\033[0m'; B=$'\033[1m'
    # Arka plan: resimdeki magenta #FD3DB5 (24-bit truecolor: R=253 G=61 B=181)
    PINK_BG=$'\033[48;2;253;61;181m'; WHITE=$'\033[1;97m'
    CYAN=$'\033[1;96m'; GREEN=$'\033[1;92m'; YELL=$'\033[1;93m'; GREY=$'\033[0;90m'
else
    R=""; B=""; PINK_BG=""; WHITE=""; CYAN=""; GREEN=""; YELL=""; GREY=""
fi

###############################################################################
#  BUYUK HATIRLATMA BANNERI  (her acilista en ustte, dikkat cekici)
###############################################################################
banner() {
    local w=64
    # Bir satiri w hucre genislige tamamlar (arka plan bosluklarla dolar)
    solid_row() { printf "%s%*s%s\n" "$PINK_BG$WHITE" "$w" "" "$R"; }
    # $1=metin  $2=metnin ekrandaki hucre uzunlugu  -> ortalanmis, tam genislik
    text_row() {
        local text="$1" len="$2"
        local padl=$(( (w - len) / 2 ))
        local padr=$(( w - len - padl ))
        printf "%s%*s%s%*s%s\n" "$PINK_BG$WHITE" "$padl" "" "$text" "$padr" "" "$R"
    }
    echo
    solid_row
    text_row "MAGNEZYUM İLACINI ALMAYI UNUTMA  🤍" 35
    solid_row
    echo
    # Buyuk "MERVE İÇİN" (bypass logosu tarzinda) + "bypass" normal yazi
    cat <<EOF
${CYAN}${B}███╗   ███╗███████╗██████╗ ██╗   ██╗███████╗  ██╗ ██████╗██╗███╗   ██╗
████╗ ████║██╔════╝██╔══██╗██║   ██║██╔════╝  ██║██╔════╝██║████╗  ██║
██╔████╔██║█████╗  ██████╔╝██║   ██║█████╗    ██║██║     ██║██╔██╗ ██║
██║╚██╔╝██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝    ██║██║     ██║██║╚██╗██║
██║ ╚═╝ ██║███████╗██║  ██║ ╚████╔╝ ███████╗  ██║╚██████╗██║██║ ╚████║
╚═╝     ╚═╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝  ╚═╝ ╚═════╝╚═╝╚═╝  ╚═══╝${R}
${WHITE}${B}bypass${R}  ${GREY}·  created by pargusz${R}
EOF
    echo
}

###############################################################################
#  nfqws DPI atlatma stratejileri  (GoodbyeDPI -5/-6/-9 karsiliklari)
###############################################################################
build_args() {
    local strat="$1"
    local -n arr="$2"

    local tls="@${DIR}/fake/tls_clienthello_www_google_com.bin"
    local quic="@${DIR}/fake/quic_initial_www_google_com.bin"

    case "$strat" in
        ttl)   # GoodbyeDPI -5 benzeri: fake paket + otomatik TTL
            arr=(
                --filter-tcp=80  --dpi-desync=fake,multisplit --dpi-desync-split-pos=1
                    --dpi-desync-autottl=-1:3-20 --dpi-desync-fooling=md5sig
                --new
                --filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld
                    --dpi-desync-autottl=-1:3-20 --dpi-desync-repeats=6 --dpi-desync-fake-tls="$tls"
                --new
                --filter-udp=443 --dpi-desync=fake --dpi-desync-autottl=-1:3-20
                    --dpi-desync-repeats=6 --dpi-desync-fake-quic="$quic"
                --new
                --filter-udp=${UDP_LO}-${UDP_HI} --filter-l7=discord,stun
                    --dpi-desync=fake --dpi-desync-autottl=-1:3-20 --dpi-desync-repeats=6
            ) ;;
        badseq)  # GoodbyeDPI -6/-9 benzeri: yanlis sira/checksum
            arr=(
                --filter-tcp=80  --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1
                    --dpi-desync-fooling=badseq,badsum
                --new
                --filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld
                    --dpi-desync-repeats=6 --dpi-desync-fooling=badseq,badsum --dpi-desync-fake-tls="$tls"
                --new
                --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="$quic"
                --new
                --filter-udp=${UDP_LO}-${UDP_HI} --filter-l7=discord,stun
                    --dpi-desync=fake --dpi-desync-repeats=6
            ) ;;
        *)  # varsayilan: dengeli fake + bolme/karistirma
            arr=(
                --filter-tcp=80  --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1
                    --dpi-desync-fooling=md5sig,badseq
                --new
                --filter-tcp=443 --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld
                    --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-fake-tls="$tls"
                --new
                --filter-udp=443 --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic="$quic"
                --new
                --filter-udp=${UDP_LO}-${UDP_HI} --filter-l7=discord,stun
                    --dpi-desync=fake --dpi-desync-repeats=6
            ) ;;
    esac
}

###############################################################################
#  Guvenlik duvari (NFQUEUE) - nft varsa nft, yoksa iptables
###############################################################################
FW=""    # "nft" | "iptables"

fw_up() {
    if command -v nft >/dev/null 2>&1; then
        FW="nft"
        nft delete table inet "$TABLE" 2>/dev/null || true
        nft -f - <<EOF
table inet ${TABLE} {
    chain postrouting {
        type filter hook postrouting priority mangle; policy accept;
        meta mark and ${MARK} == ${MARK} accept
        oifname "lo" accept
        meta l4proto tcp tcp dport { 80, 443 } ct original packets 1-6 queue num ${QNUM} bypass
        meta l4proto udp udp dport 443 ct original packets 1-9 queue num ${QNUM} bypass
        meta l4proto udp udp dport ${UDP_LO}-${UDP_HI} ct original packets 1-12 queue num ${QNUM} bypass
    }
}
EOF
    elif command -v iptables >/dev/null 2>&1; then
        FW="iptables"
        local CB="-m connbytes --connbytes-dir=original --connbytes-mode=packets"
        local NOMARK="-m mark ! --mark ${MARK}/${MARK}"
        local NFQ="-j NFQUEUE --queue-num ${QNUM} --queue-bypass"
        for ipt in iptables ip6tables; do
            command -v "$ipt" >/dev/null 2>&1 || continue
            "$ipt" -t mangle -A POSTROUTING ! -o lo -p tcp -m multiport --dports 80,443 $CB --connbytes 1:6 $NOMARK $NFQ 2>/dev/null || true
            "$ipt" -t mangle -A POSTROUTING ! -o lo -p udp --dport 443 $CB --connbytes 1:9 $NOMARK $NFQ 2>/dev/null || true
            "$ipt" -t mangle -A POSTROUTING ! -o lo -p udp --dport ${UDP_LO}:${UDP_HI} $CB --connbytes 1:12 $NOMARK $NFQ 2>/dev/null || true
        done
    else
        echo "${YELL}HATA:${R} Sistemde 'nft' veya 'iptables' bulunamadi." >&2
        echo "Ubuntu'da normalde ikisi de vardir. Su komutla kurabilirsin:  sudo apt install nftables" >&2
        exit 1
    fi
}

fw_down() {
    if [[ "$FW" == "nft" ]]; then
        nft delete table inet "$TABLE" 2>/dev/null || true
    elif [[ "$FW" == "iptables" ]]; then
        local CB="-m connbytes --connbytes-dir=original --connbytes-mode=packets"
        local NOMARK="-m mark ! --mark ${MARK}/${MARK}"
        local NFQ="-j NFQUEUE --queue-num ${QNUM} --queue-bypass"
        for ipt in iptables ip6tables; do
            command -v "$ipt" >/dev/null 2>&1 || continue
            "$ipt" -t mangle -D POSTROUTING ! -o lo -p tcp -m multiport --dports 80,443 $CB --connbytes 1:6 $NOMARK $NFQ 2>/dev/null || true
            "$ipt" -t mangle -D POSTROUTING ! -o lo -p udp --dport 443 $CB --connbytes 1:9 $NOMARK $NFQ 2>/dev/null || true
            "$ipt" -t mangle -D POSTROUTING ! -o lo -p udp --dport ${UDP_LO}:${UDP_HI} $CB --connbytes 1:12 $NOMARK $NFQ 2>/dev/null || true
        done
    fi
}

###############################################################################
#  Mimariye gore gomulu nfqws binary'sini sec
###############################################################################
pick_nfqws() {
    local m; m="$(uname -m)"
    case "$m" in
        x86_64|amd64)            echo "${DIR}/bin/linux-x86_64/nfqws" ;;
        aarch64|arm64)           echo "${DIR}/bin/linux-arm64/nfqws" ;;
        armv7l|armv6l|armhf|arm) echo "${DIR}/bin/linux-arm/nfqws" ;;
        i386|i486|i586|i686)     echo "${DIR}/bin/linux-x86/nfqws" ;;
        *)                       echo "" ;;
    esac
}

###############################################################################
#  Ana akis
###############################################################################
main() {
    # Yonetici (root) izni gerekir - Windows'taki "Yonetici olarak calistir" gibi.
    if [[ "$(id -u)" -ne 0 ]]; then
        echo "${YELL}Yonetici izni gerekiyor${R} (Windows'taki 'Yonetici olarak calistir' gibi)..."
        exec sudo -- "$SELF" "$STRAT"
    fi

    clear 2>/dev/null || true
    banner

    local NFQWS; NFQWS="$(pick_nfqws)"
    if [[ -z "$NFQWS" || ! -f "$NFQWS" ]]; then
        echo "${YELL}HATA:${R} Bu islemci mimarisi ($(uname -m)) icin gomulu nfqws yok." >&2
        exit 1
    fi
    chmod +x "$NFQWS" 2>/dev/null || true

    local args=()
    build_args "$STRAT" args

    # Cikista temizlik (pencere kapatilinca / Ctrl+C)
    local pid=""
    cleanup() {
        trap - INT TERM HUP EXIT      # cift temizligi onle
        echo
        echo "${GREY}Kapatiliyor, kurallar temizleniyor...${R}"
        [[ -n "$pid" ]] && kill "$pid" 2>/dev/null || true
        wait "$pid" 2>/dev/null || true
        fw_down
        echo "${GREY}Merve için bypass kapatildi. Iyi gunler 🤍${R}"
        exit 0
    }
    trap cleanup INT TERM HUP EXIT

    fw_up

    # Motoru calistir; teknik ciktisi ekrani doldurmasin diye log dosyasina yaz.
    local LOG="${DIR}/bypass.log"
    "$NFQWS" --qnum="$QNUM" "${args[@]}" >"$LOG" 2>&1 &
    pid=$!
    sleep 1
    if ! kill -0 "$pid" 2>/dev/null; then
        echo "${YELL}  ✖  Motor baslatilamadi.${R} Son kayitlar (${LOG}):"
        tail -n 12 "$LOG" 2>/dev/null | sed 's/^/    /'
        exit 1
    fi

    echo "${GREEN}${B}  ✔  Merve için bypass ACIK${R}   ${GREY}(yontem: ${STRAT} · motor: ${FW})${R}"
    echo "${WHITE}     Discord'u ve engelli siteleri artik acabilirsin.${R}"
    echo "${GREY}     Kapatmak icin bu pencereyi kapat veya Ctrl+C yap.${R}"
    echo "${GREY}     Calismazsa: sudo ./bypass.sh ttl  /  sudo ./bypass.sh badseq${R}"

    wait "$pid"
}

main "$@"
